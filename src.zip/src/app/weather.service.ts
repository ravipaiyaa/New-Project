import { Injectable } from '@angular/core';
import { HttpClient } from '../../node_modules/@angular/common/http';
import 'rxjs/add/operator/map';
@Injectable({
  providedIn: 'root'
})
export class WeatherService {
  url= 'http://samples.openweathermap.org/data/2.5/history/city?q=Warren,OH&appid=b6907d289e10d714a6e88b30761fae22';
  constructor(private http: HttpClient) { }
  getalllist(){
    return this.http.get(this.url).map(result => result);
  }
}
