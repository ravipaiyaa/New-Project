// import { NgModule }   from '@angular/core';
// import { CommonModule }   from '@angular/common';
// import { ReactiveFormsModule }    from '@angular/forms';

// // import { CountryComponent }  from './country.component';
// // import { AddCountryComponent }  from './add-country/add-country.component';
// // import { CountryListComponent }  from './country-list/country.list.component';
// // import { CountryDetailComponent }  from './country-list/detail/country.detail.component';
// // import { CountryEditComponent }  from './country-list/edit/country.edit.component';
// // import { CountryService } from './service/country.service';

// import { AnalyseRoutingModule } from './analyse.routing.module';
// import { AnalyseComponent } from './analyse.component';
// import { CourseComponent } from './course/course.component';
// import { UsersComponent } from './users/users.component';

// @NgModule({
//   imports: [     
//     CommonModule,
// 	ReactiveFormsModule,
// 	AnalyseRoutingModule
//   ], 
//   declarations: [
// 	AnalyseComponent,
//     CourseComponent,
//     UsersComponent
	
//   ],
//   providers: [ ]
// })
// export class AnalyseModule { } 
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

// import { AnalyseRoutingModule } from './analyse.routing.module';
 import { AnalyseComponent } from './analyse.component';
 import { CourseComponent } from './course/course.component';
 import { UsersComponent } from './users/users.component';

const routes: Routes = [
	{
		path: 'analyse',
		component: AnalyseComponent,
		children: [
      {
				path: 'course',
				component: CourseComponent
			},{
				path: 'users',
				component: UsersComponent
			}
		]
	}
];

@NgModule({
  imports: [
    CommonModule,RouterModule.forChild(routes)
  ],
  exports: [RouterModule],
  declarations: [CourseComponent, UsersComponent]
})
export class AnalyseModule { } 