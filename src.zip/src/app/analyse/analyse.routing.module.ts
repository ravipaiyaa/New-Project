// import { NgModule } from '@angular/core';
// import { Routes, RouterModule } from '@angular/router';
// import { CourseComponent } from './course/course.component';
// import { AnalyseComponent } from './analyse.component';
// import { UsersComponent } from './users/users.component';
// const analyseRoutes: Routes = [
//     { 
//             path: '',
//             component: AnalyseComponent,
//             children: [ 
//           {
//              path: 'course',
//              component: CourseComponent
//           },
//           {
//              path: 'users',
//              component: UsersComponent,
           
//            }	
//          ]
//       }  
// ];
// @NgModule({
//     imports: [ RouterModule.forChild(analyseRoutes) ],
//     exports: [ RouterModule ]
//   })
//   export class AnalyseRoutingModule{ } 