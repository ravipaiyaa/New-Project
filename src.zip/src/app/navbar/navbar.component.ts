import { Component, OnInit,Input,Output } from '@angular/core';
import { PostService } from '../post.service';
import { AppGlobals } from '../app.gloabal';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
})

export class NavbarComponent implements OnInit {
  @Input()ismailenable:boolean;
  @Input()textContent:string;
  //testing="Test";
  constructor(public service:PostService, private _global: AppGlobals) { }
  public session;
  ngOnInit() {
     this.service.getthesessiondetails().subscribe(Response=>{
       
       this.session = Response;
       console.log("The session");
       console.log(this.session);
     })
    // this.session = this.service.getthesessiondetails();
    // console.log(this.session);
  }

  getclick(){
    console.log("Test");
    this.ismailenable=!this.ismailenable;
  }
  getthe
}
