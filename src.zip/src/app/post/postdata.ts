export interface datadetails{
    id:number;
    firstname:string;
    lastname:string;
}