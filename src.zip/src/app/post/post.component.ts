import { Component, OnInit } from '@angular/core';
//import { HttpClient } from '../../../node_modules/@angular/common/http';
import { PostService } from '../post.service';
import { error } from 'util';
//import { main
@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {
  posts;
  post;
  errormsg;
  constructor(private service : PostService) { 
   
   
     
  }

  ngOnInit() {
    
    this.service.getPosts().subscribe(result=>{
      console.log(result);
      this.posts= result;
     
    },error =>this.errormsg=error);
  }
  createpost(title){
   // console.log(this.service.creatingpost(title.value));
   let post= {title:title.value};
    this.service.creatingpost(title.value).subscribe(Response=>{
      console.log(Response);
      post['id']=25;
      console.log(post);
      this.posts.splice(0,0,post);
    },error=>{
      console.log(error);
    })
    title.value='';

  }
  updatepost(post){
    this.service.updatingpost(post).subscribe(Response =>{
      console.log(Response);
    })
  }

}
