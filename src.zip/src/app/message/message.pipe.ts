import {Pipe,PipeTransform} from '@angular/core';
@Pipe({
        name:'mess'
})
export class messagepipe implements PipeTransform{

    transform(args:string,val:any){
        if(!args)
        return null;
        return args.substr(0,20)+'..';
    }
}
