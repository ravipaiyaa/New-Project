//import {Injectable, inject} from '@angular/core';
import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse} from '../../../node_modules/@angular/common/http';
import { Observable } from '../../../node_modules/rxjs';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
//import {}
@Injectable({
    providedIn: 'root'
  })
export class Messageservice{

    constructor(private httpservice:HttpClient){

    }
    private url='http://ilearn.omegahms.com/omega/local/ajax.php?id=4';
    getuserdata():Observable<Object>{
       return this.httpservice.get<Object>(this.url)
                              .catch(this.errorhabler)
    }
    errorhabler(httperror:HttpErrorResponse)
    {
        return Observable.throw(httperror.message || "server error");
    }

} 