import {Directive,HostListener} from '@angular/core';
@Directive({
    'selector':'[appconten]'
})
export class messagedirective{
    @HostListener('focus') onfocus(){
        console.log("Test");
    }
    @HostListener('mouseover') onmouseover(){
        console.log("Tes");
    }
    constructor(){

    }
}