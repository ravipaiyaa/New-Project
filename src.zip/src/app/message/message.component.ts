import { Component, OnInit } from '@angular/core';
import { Messageservice } from './message.service';
import { error } from '../../../node_modules/protractor';

@Component({
  selector: 'app-message',
  templateUrl: './message.component.html',
  styleUrls: ['./message.component.css']
})
export class MessageComponent implements OnInit {

  post;
  viewerro;
  data;
  
  constructor(private message: Messageservice) {
   
  }
  ngOnInit() {
    this.getData();
    this.data = [
      { 'name': 'Anil', 'anil.singh581@gmail.com': 'ssd', 'age': '34', 'city': 'Noida, UP, India' },
      { 'name': 'Anil', 'email': 'anil.singh581@gmail.com', 'age': '34', 'city': 'Noida' },
      { 'name': 'Sunil', 'email': 'anil.singh581@gmail.com', 'age': '34', 'city': 'Noida' },
      { 'name': 'Alok', 'email': 'anil.singh581@gmail.com', 'age': '34', 'city': 'Noida' },
      { 'name': 'Tinku', 'email': 'anil.singh581@gmail.com', 'age': '34', 'city': 'Noida' },
      { 'name': 'XYZ', 'email': 'anil.singh581@gmail.com', 'age': '34', 'city': 'Noida' },
      { 'name': 'asas', 'email': 'anil.singh581@gmail.com', 'age': '34', 'city': 'Noida' },
      { 'name': 'erer', 'email': 'anil.singh581@gmail.com', 'age': '34', 'city': 'Noida' },
      { 'name': 'jhjh', 'email': 'anil.singh581@gmail.com', 'age': '34', 'city': 'Noida' }
    ]
    console.log(this.data);

    
  }
  columnDefs = [
    {headerName: 'Make', field: 'make',sortable: true, filter: true},
    {headerName: 'Model', field: 'model',sortable: true, filter: true},
    {headerName: 'Price', field: 'price'}
];

rowData = [
    { make: 'Toyota', model: 'Celica', price: 35000 },
    { make: 'Ford', model: 'Mondeo', price: 32000 },
    { make: 'Porsche', model: 'Boxter', price: 72000 }
];
  

  getData() {
    this.message.getuserdata().subscribe(result => {
      console.log(result);
      this.post = result
    }, error => {
      this.viewerro = error
    });
  }

  
}
