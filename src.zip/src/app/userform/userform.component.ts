import { Component, OnInit } from '@angular/core';
import { PostService } from '../post.service';
import { Observable, Observer } from '../../../node_modules/rxjs';

@Component({
  selector: 'app-userform',
  templateUrl: './userform.component.html',
  styleUrls: ['./userform.component.css']
})
export class UserformComponent implements OnInit {
  user;
  singleuser;
  private data;
  constructor(private service :PostService) { }

  ngOnInit() {

      
    this.service.getPosts().subscribe(Response=>{
      console.log(Response);
      this.data = Response;
    })

      this.service.getPosts().subscribe(res=>{
       console.log("Test");
      this.user=res;
      
     
    })
    const number = Observable.create((observer: Observer<string>)=>{
      setTimeout(()=>{
        observer.next('firstpackage');
      },2000);
      setTimeout(()=>{
        observer.next('secondpackage');
      },3000);
      setTimeout(()=>{
        observer.error('error package');
      },3000);
    });
    number.subscribe(
      (data:string)=>{
        console.log(data);
      },
      (error:string)=>{
        console.log(error);
      },
      ()=>{
        console.log('completed');
      }
    );
  }
  onChange(event){
    this.service.getsingleuser(event).subscribe(res=>{
      this.singleuser=res;
      console.log(this.singleuser);
    });
   
    
    
  }

}
