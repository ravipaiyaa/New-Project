import { Component, OnInit,Input  } from '@angular/core';
import { PostService } from '../post.service';
import { add, subtract } from 'add-subtract-date';
@Component({
  selector: 'app-maincontent',
  templateUrl: './maincontent.component.html',
  styleUrls: ['./maincontent.component.css']
})
export class MaincontentComponent implements OnInit {
  
  constructor(private service:PostService) { }
  private data;
  private dashboard;
  public now;
  public getbatcid;
  public userwithbatch;
  private batchdetails
  private dataRefresher: any;
  private cachebatchdetails;
  private graphdetails: any={};
  private twominutes;
  private twominutesonly;
  public nameofbatch;
  public userid;
  private so=0;
  //@Input() value: number = this.data;
  ngOnInit() {
  this.getData(true);
  this.refreshData(); 
  
  this.getdefaultgraph(this.so);
  this.getthedashboard();

  }
  /*******The Dashboard Batch Details******/
  getthedashboard(){
    this.dashboard=this.service.getbatchdetails().subscribe(Response=>{
      //console.log(Response);
     this.batchdetails = Response;
     this.cachebatchdetails = Response;
   });
  }
  /*********The Dashboard Details for Online, Users Count********/
  getData(setPageFlag){
    this.dashboard=this.service.getdashboard().subscribe(Response=>{
      //console.log(Response);
      this.dashboard = Response;
      console.log("checking userid");
      
      this.userid=this.dashboard.userid;
      console.log(this.userid);
      
    });
  }
  /*******Get The Function Trigger For the Below Mentioned***/ 
  refreshData(){
    this.dataRefresher =
      setInterval(() => {
        this.getData(false);
        this.getthedashboard();
        //Passing the false flag would prevent page reset to 1 and hinder user interaction
      }, 30000);  
  }
  /*********To get filter data*****/ 
  filterbatches(filterVal: any){
    console.log(filterVal);
    if (filterVal == "0")
    this.batchdetails = this.cachebatchdetails;
  else
    this.batchdetails = this.cachebatchdetails.filter((item) => item.location == filterVal);
  }
  
  /******The Chart Details *******/
  public chartType: string = 'line';
  public defaultchartdata1 = Array();
  public defaultchartdata2 = Array(); 
  public defaultchartlabel = Array();
  public chartDatasets: Array<any>;
  public chartLabels;
  //public chartColors; 

  getdefaultgraph(option:number){
    this.defaultchartdata1 =[];
    this.defaultchartlabel =[];

    this.service.getthedefaultgraph(option).subscribe(Response=>{
     
      let scgraphdata = Response;
      
        Object(scgraphdata).forEach( (item) => {
          console.log(item);
        this.defaultchartlabel.push(""+item.batch+"");
        
        this.defaultchartdata1.push(""+item.batchperformance+"");
       
        this.defaultchartdata2.push(""+item.percentage+"");
      });
      this.defaultchartdata1.push(100);
      this.defaultchartdata1.push(0);
      console.log("cheart"+this.defaultchartdata1);
      this.chartDatasets=[
        { data: this.defaultchartdata1, label: 'Batch' }
        
      ];
      this.chartLabels=this.defaultchartlabel;
    })
    
  }
  
  public chartColors: Array<any> = [
    {
      backgroundColor: 'rgba(105, 0, 132, .2)',
      borderColor: 'rgba(200, 99, 132, .7)',
      borderWidth: 2,
    },
      {
        backgroundColor: 'rgba(0, 137, 132, .2)',
        borderColor: 'rgba(0, 10, 130, .7)',
        borderWidth: 2,
      }
  ];

  public chartOptions: any = {
    responsive: true
  };
  public chartClicked(e: any): void { }
  public chartHovered(e: any): void { }
  /******The Chart Details ends here*******/

  /**************The Below function Trigered When user clicks on analze **************/
  public chartType1: string ;
  public chartDatasets1: Array<any>;
  public chartLabels1: Array<any>;
  public chartColors1: Array<any>;
  public chartOptions1: any;
  public chartClicked1(e: any): void { }
  public chartHovered1(e: any): void { }
  public graphdata:any;
  public scores:any;
  public users;
  public  chartdata = Array();
  public  chartlabel = Array();
  public color = Array();
  public food= [
    {value: 'steak-0', viewValue: 'Steak'},
    {value: 'pizza-1', viewValue: 'Pizza'},
    {value: 'tacos-2', viewValue: 'Tacos'}
  ];
  getoldgraph(){
    //alert("test");
    this.graphdetails={
      batch:'',
      batchstatus:false
    };
    this.getdefaultgraph(this.so);  
  }
  /********Batch wise Graph code below********/
  getgraph(batchname,id,include){
    //alert(batchname);
    this.chartdata =[];
    this.chartlabel =[];
    this.color=[];
    this.graphdetails={
      batch:batchname,
      batchstatus:true,
      batchid:id
    };
    
    this.service.getgraphdetailsforbatch(id,include).subscribe(Response=>{
    this.graphdata = Response;
   
    this.users = this.graphdata.users;
    this.scores = Response['scores'];
    let scdata = this.graphdata;
    var res = Math.max.apply(Math,scdata.map(function(o){return o.score;}))
    console.log(res);
    // let min = Math.min(...arr);
    // let max = Math.max(arr);
    Object(scdata).forEach( (item) => {
      this.chartlabel.push(""+item.uname+"");
      this.chartdata.push(""+item.score+"");
      if(item.score>=70){
        this.color.push('rgba(72, 179, 97, 0.5)');
      }else if(item.score>60 && item.score<70){
        this.color.push('rgba(200, 99, 132, .7)');
        
      }else{
        if(item.status=='transfer'){
          this.color.push('rgba(206, 3, 3, 1)');
        }else if(item.status=='drop'){
         
          this.color.push('rgba(15, 185, 194, 1)');
          
        }else{
          this.color.push('rgba(255, 159, 132, 0.2)');
        }
        
      }
      
    });


    //  console.log(this.chartlabel);
    //  console.log(this.chartdata);
     this.chartLabels1=this.chartlabel;
     this.chartDatasets1 = [
      { data: this.chartdata, label: 'Score' }
  ];
    });
    this.chartType1= 'bar';
    this.chartColors1 = [
    {
      backgroundColor:this.color,
      borderColor: this.color,
      borderWidth: 2,
    }
  ];
    this.chartOptions1 = {
      responsive: true
    };
   this.totalusercountdetails(id,batchname);
  }
  totalusercountdetails(batchid,batchname){
    this.getbatcid = batchid;
    this.nameofbatch=batchname;
    this.now = new Date()
    this.twominutes =subtract(this.now, 1, "minutes");
    this.twominutesonly=this.twominutes.getHours() + ':' + this.twominutes.getMinutes();
    console.log(subtract(this.now, 25, 'days'));
    console.log(subtract(this.now, 10, "minutes"));
    console.log(this.now.getMonth());
    // this.service.getPosts().subscribe(Response=>{
    //   console.log(Response);
    //   this.data = Response;
    // })
    this.service.getonlineuserdetails(batchid).subscribe(Response=>{
      console.log("onlie");
      console.log(Response);
      this.data = Response;
    })
    // this.service.getonlineuserdetails().subscribe(results=>{

    // })

  }
  getuserprogress(userid,batchid){
    console.log(batchid);
    console.log(userid);
    this.service.gettheuserbatchdetails(userid,batchid).subscribe(Response=>{
      this.userwithbatch = Response;
    })
  }
    
}
