import { Injectable } from '@angular/core';
import { PostService } from './post.service';

@Injectable()
export class AppGlobals {
    // constructor(public service:PostService){

    // }
    constructor(private service:PostService){
    //     console.log("eeee");
    //    console.log(this.service.getthesessiondetails());
    }
    
    //readonly baseUser: any = this.service.getthesessiondetails();
    readonly baseAppUrl: string = 'http://localhost:57431/';
    readonly baseAPIUrl: string = 'https://api.github.com/';
}