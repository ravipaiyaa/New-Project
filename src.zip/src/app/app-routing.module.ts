import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PostComponent } from './post/post.component';
import { UserformComponent } from './userform/userform.component';
import { MaincontentComponent } from './maincontent/maincontent.component';
import {AnalyseComponent} from './analyse/analyse.component'
import { MessageComponent } from './message/message.component';
import { AuthGuard } from './guards/auth-guard.service';
import {AnalyseModule} from './analyse/analyse.module';
//import { AuthGuard } from '../guards/auth-guard.service';
 const routes: Routes = [
    {path:'maincontent',component:MaincontentComponent,canActivate: [AuthGuard]},
    {path:'post',component:PostComponent},
    {path:'userform',component:UserformComponent},
    {path:'analyse',loadChildren: () =>AnalyseModule},
    {path:'message',component:MessageComponent},
    {path:'**',component:MaincontentComponent}

 ];
 @NgModule({
   imports: [RouterModule.forRoot(routes)],
   exports: [RouterModule]
 })
export class AppRoutingModule { }
