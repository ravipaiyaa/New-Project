import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '../../node_modules/@angular/common/http';
import { Observable, observable } from '../../node_modules/rxjs';

//import { mergeMap, retry } from 'rxjs/operators';
import {datadetails } from '../app/post/postdata';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/retry';

@Injectable({
  providedIn: 'root'
})
export class PostService {
private url = 'http://lms.omegahms.com/omcalms/';
private url1 ='http://lms.omegahms.com/omcalms/local/ajax.php?id=1';
private url2 ='http://lms.omegahms.com/omcalms/local/ajax.php?id=2';
private url3 ='http://lms.omegahms.com/omcalms/local/ajax.php';

  constructor(private http : HttpClient) { }

  getPosts():Observable<Object>{
    return this.http.get<Object>(this.url1)
                    .catch(this.errorhandler);
  }
  errorhandler(httperror:HttpErrorResponse){
    return Observable.throw(httperror.message || "server error");
  }
  creatingpost(title){
    let data ={
      tit:title,
    }
    
     // console.log(JSON.stringify(data));
      return this.http.post(this.url2,JSON.stringify(data));
  }
  updatingpost(post){
   // console.log(post);
    return this.http.put(this.url2 + '/' +post.id,post);
  }
  getsingleuser(id){
    //console.log(id);
    return this.http.get(this.url3 +'?id=6'+ '&userid=' +id);
  }
  getdashboard(){
    return this.http.get('http://lms.omegahms.com/omcalms/local/ajax.php?id=4').retry();
  }
  getbatchdetails(){
    return this.http.get(this.url+'local/ajax.php?id=5').retry();
  }
  getonlineuserdetails(users){
    
    return this.http.get(this.url3 +'?id=6'+ '&batchid=' +users);
  }
  getthesessiondetails(){
    
    return this.http.get(this.url3 +'?id=7').retry();
  }
  getgraphdetailsforbatch(batcid,include){
    return this.http.get(this.url3 +'?id=8'+ '&batchid=' +batcid+'&include='+include).retry();
  }
  getthedefaultgraph(option){
    
    return this.http.get(this.url3 +'?id=9'+ '&case=' +option).retry();
  }
  gettheuserbatchdetails(userid,batchid){
    return this.http.get(this.url3 +'?id=10'+ '&userid=' +userid+'&batchid='+batchid).retry();
  }
         
}
