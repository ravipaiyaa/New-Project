import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {MatButtonModule, MatCheckboxModule, MatMenuModule, MatIconModule} from '@angular/material';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { SidebarComponent } from './sidebar/sidebar.component';
import { MaincontentComponent } from './maincontent/maincontent.component';
import { PostComponent } from './post/post.component';
import { HttpClientModule } from '../../node_modules/@angular/common/http';
//import { CalendarComponent } from './calendar/calendar.component';
import { PostService } from './post.service';
import { RouterModule } from '../../node_modules/@angular/router';
import { UserformComponent } from './userform/userform.component';
import { AnalyseComponent } from './analyse/analyse.component';
import { summarypipe } from './summary.pipe';
import { WeatherService } from './weather.service';
import { ChartsModule, WavesModule, ButtonsModule, CardsFreeModule } from 'angular-bootstrap-md';
import { MessageComponent } from './message/message.component'
import { messagedirective } from './message/message.directive';
import { Messageservice } from './message/message.service';
import { messagepipe } from './message/message.pipe';
import {DataTableModule} from "angular-6-datatable";
import { AgGridModule } from 'ag-grid-angular';
import { CommonModule } from '../../node_modules/@angular/common';
import { ScrollDispatcher, ScrollingModule } from '@angular/cdk/scrolling';
import { FilterPipe} from './filter.pipe';
import { FormsModule } from '@angular/forms';
import { AppGlobals } from './app.gloabal';
import { AuthGuard } from './guards/auth-guard.service';
// import { CourseComponent } from './analyse/course/course.component';
// import { UsersComponent } from './analyse/users/users.component';
import { AnalyseModule } from './analyse/analyse.module';
import { FooterComponent } from './footer/footer.component';
//import { ComponentsModule } from './components/components.module';
@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    SidebarComponent,
    MaincontentComponent,
    PostComponent,
    UserformComponent,
    AnalyseComponent,
    summarypipe,
    MessageComponent,
    messagedirective,
    messagepipe,
    FilterPipe,
    FooterComponent
    
  ],
  imports: [
    BrowserModule,
    AnalyseModule,
    NgbModule.forRoot(),
    MatButtonModule, 
    MatCheckboxModule,
    MatMenuModule,
    ChartsModule,
    WavesModule,
    MatIconModule,
    AngularFontAwesomeModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    DataTableModule,
    RouterModule,
    CommonModule,
    ScrollingModule,
    FormsModule,
    ButtonsModule,
    CardsFreeModule,
    AgGridModule.withComponents([])
  ],
  providers: [
    PostService,
    WeatherService,
    Messageservice,
    ScrollDispatcher,
    AppGlobals,
    AuthGuard
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
