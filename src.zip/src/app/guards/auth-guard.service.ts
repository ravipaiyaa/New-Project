
//import { AuthService } from './../services/auth.service';
import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router, Route } from '@angular/router';
import { Observable } from 'rxjs';
import { PostService } from '../post.service';
import { HttpClient } from '../../../node_modules/@angular/common/http';

@Injectable()
export class AuthGuard implements CanActivate {
  private url = 'http://lms.omegahms.com/omcalms/local/ajax.php';
  private data:object;
  constructor(private _router: Router,private http:HttpClient) {
    this.http.get(this.url +'?id=7').subscribe(Response=>{
      this.data=Response;
     
  
    })
  }
  

  // canActivate() {
  //   return this.http.get(this.url +'?id=7').retry();
  //   // this._router.navigate(['/userform']);
  //   // // you can save redirect url so after authing we can move them back to the page they requested
  //   //return false;
  // }
  canActivate() {
    
    console.log(this.data);
    if (this.data) {
      console.log("True userlogin");
      return true;
    } else {
      this._router.navigate(['/userform']);
      // window.alert("You don't have permission to view this page"); (4)
      return false;
    }
  }

}
