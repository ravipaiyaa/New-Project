import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
     name :'sumtest'
})
export class summarypipe implements PipeTransform{

    transform(value : string,arg :any){
        
         if(!value)
         return null;
        return value.substr(0,5)+'..............';
    }
}