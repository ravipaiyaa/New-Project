import React from 'react'
function App() {
    let a = 100
    let b = 10.2
    let c = "welcome"
    let d = [1, 2, 3, 4, 5, 6]
    let e = ["a", "b", "c", "d"]
    let f = ["html", "css", 'js']
    let ob = { id: 1, name: "demo1", email: "demo1@gmail.com" }
    return <div>
        <h1>{a}</h1>
        <h1>{b}</h1>
        <h1>{c}</h1>
        <h1>{d}</h1>
        <h1>{e}</h1>
        <h1>{f}</h1>
        <h1>{ob.toString()}</h1>
        <h1>{JSON.stringify(ob)}</h1>
    </div>
}
export default App