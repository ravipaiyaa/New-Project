import React from 'react'

export const Button=()=><button>click me</button>
export const Input=()=><input type='date' />
export const Highlighted=()=><mark>Highlighted</mark>