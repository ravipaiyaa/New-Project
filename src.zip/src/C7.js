import React from 'react'
function App() {
    let a = [1, 2, 3, 4, 5, 6]
    let b = ["a", "b", "c", "d"]
    let c = ["html", "css", 'js']
    return <div>
        <h1>{a}</h1>
        <h1>{b}</h1>
        <h1>{c}</h1>
        <h2>{a.filter(item => item % 2 === 0)}</h2>
        <h2>{b.filter(item => item.charCodeAt(0) > 98)}</h2>
        <h2>{c.filter(item => item.includes("s"))}</h2>

        {a.map(x => <li>{x}</li>)}
        {b.map(x => <li>{x}</li>)}
        {c.map(x => <li>{x}</li>)}

        {[...a, ...b, ...c].map(x => <marquee>{x}</marquee>)}
    </div>
}
export default App