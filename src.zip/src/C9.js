import React from 'react'

function App() {

    const [a, seta] = React.useState([0])
    const addmore=()=>{
        seta([...a,0])
    }
    return <div>
        <button onClick={addmore}>+</button>
        {a.map((item,index,arr) =>
            <div>
                {index+1}: Skills <input />
            </div>
        )}
    </div>
}
export default App