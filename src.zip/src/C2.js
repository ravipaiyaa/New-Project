import React from 'react'

const App = () => <h1>Example2 Works </h1>
export default App