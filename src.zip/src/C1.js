import React from 'react'

function App()
{
    return <h1>Example1 Works</h1>   
}
export default App