import React from 'react'

function App() {

    const [x, abc] = React.useState(0)
    // x=0
    // abc=function
    //    1.always change x
    //    2.re-render whereeer x is written

    const p1 = () => abc(x + 1)
    const p2 = () => abc(x - 1)
    const p3 = () => abc(0)
    const p4 = () => abc(1000)
    const p5 = () => alert(x)


    // console.log(React.useState(420))


    return <div>
        <h1>{x}</h1>
        <button disabled={x>1000} onClick={p1}>+</button>
        <button onClick={() => p2()}>-</button>
        <button onClick={e => p3()}>0</button>
        <button onClick={ev => p4()}>1000</button>
        <button onClick={p5}>view</button>
    </div>
}
export default App